# KDT mini project
## ― A simple news site practice using Naver news API
## ― A kind of React project at front, and a Spring Boot project at back
## ― In collaboration with KDT classmates
### Further details to be confirmed…